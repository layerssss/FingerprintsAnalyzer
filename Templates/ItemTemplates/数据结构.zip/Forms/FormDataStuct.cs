﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace $rootnamespace$.Forms
{
    public partial class Form$fileinputname$ : Form
    {
        public Form$fileinputname$()
        {
            InitializeComponent();
        }
        public void LoadData($fileinputname$ data, GrayLevelImage originalImg, string dataIdent)
        {
            this.data = data;
            this.originalImg = originalImg;
            this.Text = dataIdent;
        }
        $fileinputname$ data;
        GrayLevelImage originalImg;
    }
}
