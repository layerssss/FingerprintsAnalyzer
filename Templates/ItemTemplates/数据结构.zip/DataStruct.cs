﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace $rootnamespace$
{
    public class $safeitemname$:IDataStruct
    {
        public void Allocate()
        {
        
        }
        
        #region IDataStruct 成员

        public void Serialize(System.IO.BinaryWriter writer)
        {
            throw new NotImplementedException();
        }

        public void Deserialize(System.IO.BinaryReader reader)
        {
            throw new NotImplementedException();
        }

        public bool Present(GrayLevelImage originalImg, string dataIdent)
        {
            Forms.Form$fileinputname$ f = new Forms.Form$fileinputname$();
            f.LoadData(this, originalImg, dataIdent);
            return f.ShowDialog() == System.Windows.Forms.DialogResult.OK;
        }

        public IDataStruct BuildInstance()
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
